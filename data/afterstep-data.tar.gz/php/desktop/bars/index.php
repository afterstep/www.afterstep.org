&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/bars</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/bars</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/blue.png>","blue","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/button_back_unity1.png>","button_back_unity1","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/darkblue.png>","darkblue","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/east.png>","east","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_east_breeze.png>","frame_east_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_se_breeze.png>","frame_se_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_se_unity.png>","frame_se_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_south_breeze.png>","frame_south_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_south_unity.png>","frame_south_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_west_breeze.png>","frame_west_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_west_unity.png>","frame_west_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/green.png>","green","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/menu_hilite_breeze.png>","menu_hilite_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/ostxs.png>","ostxs","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/ostxu.png>","ostxu","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/postcard_maybe.png>","postcard_maybe","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/postcard_msg.png>","postcard_msg","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/postcard_no.png>","postcard_no","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/postcard_yes.png>","postcard_yes","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/red.png>","red","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/south.png>","south","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_btn_breeze.png>","title_btn_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lbtn_qnx.png>","title_lbtn_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lspacer_glass.png>","title_lspacer_glass","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lspacer_unity.png>","title_lspacer_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_ltitle_spacer_breeze.png>","title_ltitle_spacer_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_ltitle_spacer_unity.png>","title_ltitle_spacer_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rspacer_breeze.png>","title_rspacer_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rspacer_glass.png>","title_rspacer_glass","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rspacer_unity.png>","title_rspacer_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rtitle_spacer_breeze.png>","title_rtitle_spacer_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rtitle_spacer_unity.png>","title_rtitle_spacer_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_breeze.png>","title_tile_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_focused.png>","title_tile_glass_focused","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_menu.png>","title_tile_glass_menu","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_menu_focused.png>","title_tile_glass_menu_focused","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_mi.png>","title_tile_glass_mi","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_mi_high.png>","title_tile_glass_mi_high","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_sticky.png>","title_tile_glass_sticky","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_unfocused.png>","title_tile_glass_unfocused","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_qnx_focused.png>","title_tile_qnx_focused","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_qnx_sticky.png>","title_tile_qnx_sticky","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_qnx_unfocused.png>","title_tile_qnx_unfocused","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_unity.png>","title_tile_unity","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/west.png>","west","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/btn_back_glass_red.png>","btn_back_glass_red","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/button_r15x17.png>","button_r15x17","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/button_sq10x10.png>","button_sq10x10","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/button_sq7x10.png>","button_sq7x10","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_east_glass_transp.png>","frame_east_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_e_qnx.png>","frame_e_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_ne_glass_transp.png>","frame_ne_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_north_glass_transp.png>","frame_north_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_nw_glass_transp.png>","frame_nw_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_se_glass_transp.png>","frame_se_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_se_qnx.png>","frame_se_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_se_unity_grey.png>","frame_se_unity_grey","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_south_glass_transp.png>","frame_south_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_s_qnx.png>","frame_s_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_sw_breeze.png>","frame_sw_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_sw_glass_transp.png>","frame_sw_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_sw_qnx.png>","frame_sw_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_sw_unity_grey.png>","frame_sw_unity_grey","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_west_glass_transp.png>","frame_west_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/frame_w_qnx.png>","frame_w_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/os8-title.png>","os8-title","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/ostx.png>","ostx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/southeast.png>","southeast","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/southwest.png>","southwest","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lbtn_glass.png>","title_lbtn_glass","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lbtn_qnx_1.png>","title_lbtn_qnx_1","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lbtn_qnx_2.png>","title_lbtn_qnx_2","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lspacer_breeze.png>","title_lspacer_breeze","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_lspacer_glass_transp.png>","title_lspacer_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_ltitle_spacer_unity_grey.png>","title_ltitle_spacer_unity_grey","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rbtn_glass.png>","title_rbtn_glass","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rbtn_qnx.png>","title_rbtn_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rspacer_glass_transp.png>","title_rspacer_glass_transp","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rspacer_qnx.png>","title_rspacer_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_rtitle_spacer_unity_grey.png>","title_rtitle_spacer_unity_grey","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_breeze_gloss.png>","title_tile_breeze_gloss","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_glass_red_a50.png>","title_tile_glass_red_a50","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_qnx.png>","title_tile_qnx","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_unity_bottom.png>","title_tile_unity_bottom","/desktop/bars",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/bars/title_tile_unity_top.png>","title_tile_unity_top","/desktop/bars",$subunset) ?></IMG>
</UL>