&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">postcard_msg</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/bars/postcard_msg</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">834x573</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/bars/postcard_msg</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/bars/postcard_msg.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>&lt;composite id=DeskaTopa&gt;
    &lt;tile tint=#fcfefc width=&quot;800&quot; height=&quot;570&quot;&gt;
    &lt;solid color=&quot;fcfefc&quot; opacity=&quot;80&quot; width=&quot;5&quot; height=&quot;5&quot;/&gt;
    &lt;/tile&gt;
    &lt;text y=20 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; spacing=&quot;5&quot; type=&quot;0&quot;&gt;Please  send  the  developers  a  postcard !!!&lt;/text&gt;

    &lt;text y=70 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; spacing=&quot;5&quot; type=&quot;0&quot;&gt;And finally we are coming to the fun part.&lt;/text&gt;

    &lt;text y=130 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;AfterStep is the only compensation that developers of this lousy&lt;/text&gt;
    &lt;text y=170 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;software get  -  a single message will automagically be  e-mailed&lt;/text&gt;
    &lt;text y=210 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;anytime your ~/.afterstep directory needs to be rebuilt.&lt;/text&gt;

    &lt;text y=270 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;This message  will contain such  vital information  as  date,  time,&lt;/text&gt;
    &lt;text y=310 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;your X server color depth, number of X screens, number of xinerama&lt;/text&gt;
    &lt;text y=350 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;screens, version of your compiler and kernel, and a list of  linked&lt;/text&gt;
    &lt;text y=390 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;to libraries.&lt;/text&gt;

    &lt;text y=450 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; type=&quot;0&quot;&gt;If you object to this e-mailing activity, simply deny it below.&lt;/text&gt;
    &lt;text y=510 x=30 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; spacing=&quot;5&quot; type=&quot;0&quot;&gt;That  is  all!  Now  enjoy  your  eyecandy  :)&lt;/text&gt;

    &lt;text y=550 x=1 fgcolor=&quot;#000000&quot; font=&quot;DefaultBold.ttf&quot; point=&quot;20&quot; spacing=&quot;5&quot; type=&quot;0&quot;&gt;-------------------------------------------------&lt;/text&gt;
&lt;/composite&gt;
</PRE></UL>