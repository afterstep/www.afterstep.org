&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">glass-pin-pressed</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons/glass-pin-pressed</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">18x18</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/buttons/glass-pin-pressed</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/buttons/glass-pin-pressed.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>&lt;hsv id=&quot;btn_back_active&quot; hue_offset=&quot;$ascs.Active.hue&quot;
saturation_offset=&quot;$ascs.Active.saturation-30&quot;
value_offset=&quot;$ascs.Active.value-60&quot;&gt;
  &lt;img src=&quot;bars/btn_back_glass_red&quot;/&gt;
&lt;/hsv&gt;

&lt;composite merge=&quot;clip&quot;&gt;
  &lt;recall srcid=&quot;btn_back_active&quot;/&gt;

  &lt;tile x=&quot;5&quot; y=&quot;5&quot; tint=&quot;#FFFFFF&quot;&gt;
    &lt;scale width=&quot;13&quot; height=&quot;11&quot;&gt;
      &lt;img src=&quot;dots/pin&quot;/&gt;
    &lt;/scale&gt;
  &lt;/tile&gt;

  &lt;tile tint=&quot;#6f7f7f7f&quot; x=&quot;0&quot; y=&quot;0&quot;&gt;
    &lt;recall srcid=&quot;btn_back_active&quot;/&gt;
  &lt;/tile&gt;
&lt;/composite&gt;

</PRE></UL>