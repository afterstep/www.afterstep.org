&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">as-switchwindow-b-pressed.xpm</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons/as-switchwindow-b-pressed.xpm</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">15x15</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/buttons/as-switchwindow-b-pressed.xpm</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/buttons/as-switchwindow-b-pressed.xpm.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>&lt;bevel border=&quot;1 1 3 3&quot; colors=&quot;#000000 #FFFFFF&quot; solid=&quot;0&quot;&gt;
  &lt;composite&gt;
    &lt;solid color=&quot;#C0C0C0&quot; width=&quot;15&quot; height=&quot;15&quot;/&gt;

    &lt;tile tint=&quot;#010101&quot;&gt;
      &lt;rotate angle=&quot;180&quot;&gt;
        &lt;img src=&quot;dots/arrow_gr_medium&quot;/&gt;
      &lt;/rotate&gt;
    &lt;/tile&gt;
  &lt;/composite&gt;
&lt;/bevel&gt;

</PRE></UL>