&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">as1.5-menu.xpm</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons/as1.5-menu.xpm</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">20x20</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/buttons/as1.5-menu.xpm</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/buttons/as1.5-menu.xpm.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>&lt;bevel colors=&quot;#00000000 #323232&quot; border=&quot;1 1 4 0&quot;&gt;
  &lt;pad color=&quot;#00000000&quot; left=&quot;3&quot; top=&quot;3&quot; right=&quot;2&quot; bottom=&quot;2&quot;&gt;
    &lt;rotate angle=&quot;270&quot;&gt;
      &lt;tile tint=&quot;#404040&quot;&gt;
        &lt;img src=&quot;dots/triangle_medium&quot;/&gt;
      &lt;/tile&gt;
    &lt;/rotate&gt;
  &lt;/pad&gt;
&lt;/bevel&gt;

</PRE></UL>