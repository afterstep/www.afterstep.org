&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">breeze-maxmin</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons/breeze-maxmin</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">9x14</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/buttons/breeze-maxmin</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/buttons/breeze-maxmin.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>
&lt;pad id=&quot;bg1&quot; top=&quot;1&quot; color=&quot;Black&quot;&gt;
   &lt;pad  top=&quot;1&quot; color=&quot;White&quot;&gt;
      &lt;solid color=&quot;#d5d6d5&quot; width=&quot;11&quot; height=&quot;19&quot; /&gt;
   &lt;/pad&gt;
&lt;/pad&gt;

&lt;pad  top=&quot;3&quot; color=&quot;#0fff&quot;&gt;
&lt;composite &gt;
   &lt;tile tint=&quot;#666&quot; y=&quot;2&quot; &gt;
      &lt;img  src=&quot;dots/window_thick&quot; /&gt;
   &lt;/tile&gt;
   &lt;tile tint=&quot;#444&quot; y=&quot;1&quot; &gt;
      &lt;img  src=&quot;dots/window_thick&quot; /&gt;
   &lt;/tile&gt;
   &lt;tile tint=&quot;Black&quot; y=&quot;0&quot; &gt;
      &lt;img src=&quot;dots/window_thick&quot; /&gt;
   &lt;/tile&gt;
&lt;/composite &gt;
&lt;/pad&gt;
</PRE></UL>