&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">qnx-switchwindow</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons/qnx-switchwindow</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Size : </B></DT><DD class="dense"><P class="dense">22x19</P></DD><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/buttons/qnx-switchwindow</P></DD><DT class="dense"><B>Type : </B></DT><DD class="dense"><P class="dense">XML</P></DD><DT class="dense"><B>Preview : </B></DT><DD class="dense"><IMG SRC=data/php/desktop/buttons/qnx-switchwindow.png></IMG>
</DD></DL></UL>
<A NAME="XML text : "><UL><B>XML text : </B><br></A><PRE>&lt;rotate id=&quot;arrow_short_small_icon&quot; angle=&quot;240&quot;&gt;
  &lt;img src=&quot;dots/arrow_short_small&quot;/&gt;
&lt;/rotate&gt;

&lt;rotate id=&quot;arrow_short_medium_icon_rotated&quot; angle=&quot;240&quot;&gt;
  &lt;img src=&quot;dots/arrow_short_medium&quot;/&gt;
&lt;/rotate&gt;

&lt;tile id=&quot;arrow_short_small_icon_black&quot; tint=&quot;#487f7f7f&quot;&gt;
  &lt;tile tint=&quot;InactiveText1&quot;&gt;
    &lt;scale width=&quot;11&quot; height=&quot;11&quot;&gt;
      &lt;recall srcid=&quot;arrow_short_medium_icon_rotated&quot;/&gt;
    &lt;/scale&gt;
  &lt;/tile&gt;
&lt;/tile&gt;

&lt;pad color=&quot;#00000000&quot; left=&quot;4&quot; top=&quot;3&quot;&gt;
  &lt;composite&gt;
    &lt;recall x=&quot;2&quot; y=&quot;0&quot; srcid=&quot;arrow_short_small_icon_black&quot;/&gt;

    &lt;solid x=&quot;1&quot; y=&quot;3&quot; width=&quot;13&quot; height=&quot;1&quot; color=&quot;#7Fbbbbbb&quot;/&gt;

    &lt;tile y=&quot;-2&quot; clip_height=&quot;13&quot; tint=&quot;BaseDark&quot;&gt;
      &lt;recall srcid=&quot;arrow_short_small_icon&quot;/&gt;
    &lt;/tile&gt;
  &lt;/composite&gt;
&lt;/pad&gt;

</PRE></UL>