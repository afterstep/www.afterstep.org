&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/buttons</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/buttons</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/1p.xpm.png>","1p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/1.xpm.png>","1.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/2p.xpm.png>","2p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/2.xpm.png>","2.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/3p.xpm.png>","3p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/3.xpm.png>","3.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/4p.xpm.png>","4p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/4.xpm.png>","4.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/5p.xpm.png>","5p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/5.xpm.png>","5.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-iconize-p.xpm.png>","as1.5-iconize-p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-iconizeR-p.xpm.png>","as1.5-iconizeR-p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-iconizeR.xpm.png>","as1.5-iconizeR.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-iconize.xpm.png>","as1.5-iconize.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-kill-p.xpm.png>","as1.5-kill-p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-kill.xpm.png>","as1.5-kill.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-menu-p.xpm.png>","as1.5-menu-p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-menu.xpm.png>","as1.5-menu.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-shade-p.xpm.png>","as1.5-shade-p.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as1.5-shade.xpm.png>","as1.5-shade.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-iconize-pressed.xpm.png>","as-iconize-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-iconize.xpm.png>","as-iconize.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-kill-pressed.xpm.png>","as-kill-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-kill.xpm.png>","as-kill.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-maximize-a-pressed.xpm.png>","as-maximize-a-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-maximize-a.xpm.png>","as-maximize-a.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-menu-a-pressed.xpm.png>","as-menu-a-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-menu-a.xpm.png>","as-menu-a.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-menu-b-pressed.xpm.png>","as-menu-b-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-menu-b.xpm.png>","as-menu-b.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-minimize-a-pressed.xpm.png>","as-minimize-a-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-minimize-a.xpm.png>","as-minimize-a.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-shade-a-pressed.xpm.png>","as-shade-a-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-shade-a.xpm.png>","as-shade-a.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-a-pressed.xpm.png>","as-switchwindow-a-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-a.xpm.png>","as-switchwindow-a.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-b-pressed.xpm.png>","as-switchwindow-b-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-b.xpm.png>","as-switchwindow-b.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-c-pressed.xpm.png>","as-switchwindow-c-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/as-switchwindow-c.xpm.png>","as-switchwindow-c.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/breeze-close.png>","breeze-close","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/breeze-maxmin.png>","breeze-maxmin","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/breeze-menu.png>","breeze-menu","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/breeze-shade.png>","breeze-shade","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/breeze-switchwindow.png>","breeze-switchwindow","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-iconize-dark.png>","default-iconize-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-iconize-dark-pressed.png>","default-iconize-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-iconize-light.png>","default-iconize-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-iconize-light-pressed.png>","default-iconize-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-kill-dark.png>","default-kill-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-kill-dark-pressed.png>","default-kill-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-kill-light.png>","default-kill-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-kill-light-pressed.png>","default-kill-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-menu-dark.png>","default-menu-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-menu-dark-pressed.png>","default-menu-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-menu-light.png>","default-menu-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-menu-light-pressed.png>","default-menu-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-pin-dark.png>","default-pin-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-pin-dark-pressed.png>","default-pin-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-pin-light.png>","default-pin-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-pin-light-pressed.png>","default-pin-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-shade-dark.png>","default-shade-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-shade-dark-pressed.png>","default-shade-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-shade-light.png>","default-shade-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-shade-light-pressed.png>","default-shade-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-switchwindow-dark.png>","default-switchwindow-dark","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-switchwindow-dark-pressed.png>","default-switchwindow-dark-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-switchwindow-light.png>","default-switchwindow-light","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/default-switchwindow-light-pressed.png>","default-switchwindow-light-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-iconify-pressed.xpm.png>","fuf-iconify-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-iconify.xpm.png>","fuf-iconify.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-kill-pressed.xpm.png>","fuf-kill-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-kill.xpm.png>","fuf-kill.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-shade-pressed.xpm.png>","fuf-shade-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-shade.xpm.png>","fuf-shade.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-switchwindow-pressed.xpm.png>","fuf-switchwindow-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-switchwindow.xpm.png>","fuf-switchwindow.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-windowmenu-pressed.xpm.png>","fuf-windowmenu-pressed.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/fuf-windowmenu.xpm.png>","fuf-windowmenu.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/g_iconize.xpm.png>","g_iconize.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-iconize.png>","glass-iconize","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-iconize-pressed.png>","glass-iconize-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-kill.png>","glass-kill","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-kill-pressed.png>","glass-kill-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-menu.png>","glass-menu","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-menu-pressed.png>","glass-menu-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-pin.png>","glass-pin","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-pin-pressed.png>","glass-pin-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-shade.png>","glass-shade","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-shade-pressed.png>","glass-shade-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-switchwindow.png>","glass-switchwindow","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/glass-switchwindow-pressed.png>","glass-switchwindow-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/g_shut.xpm.png>","g_shut.xpm","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-close.png>","qnx-close","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-close-pressed.png>","qnx-close-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-iconify.png>","qnx-iconify","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-iconify-pressed.png>","qnx-iconify-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-menu.png>","qnx-menu","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-menu-pressed.png>","qnx-menu-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-pin.png>","qnx-pin","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-pin-pressed.png>","qnx-pin-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-shade.png>","qnx-shade","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-shade-pressed.png>","qnx-shade-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-switchwindow.png>","qnx-switchwindow","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/qnx-switchwindow-pressed.png>","qnx-switchwindow-pressed","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/unity-close.png>","unity-close","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/unity-maxmin.png>","unity-maxmin","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/unity-menu.png>","unity-menu","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/unity-shade.png>","unity-shade","/desktop/buttons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/buttons/unity-switchwindow.png>","unity-switchwindow","/desktop/buttons",$subunset) ?></IMG>
</UL>