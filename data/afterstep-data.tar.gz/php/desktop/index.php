&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Subdirectories"><UL><B>Subdirectories</B><br></A><DL class="dense"><DT class="dense"><B><? local_doc_url("graphics.php","bars","bars/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","buttons","buttons/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","icons","icons/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","tiles","tiles/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","cursors","cursors/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","fonts","fonts/index","/desktop",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","sounds","sounds/index","/desktop",$subunset) ?></B></DT></DL></UL>