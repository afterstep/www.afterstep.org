&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/icons</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Subdirectories"><UL><B>Subdirectories</B><br></A><DL class="dense"><DT class="dense"><B><? local_doc_url("graphics.php","dots","dots/index","/desktop/icons",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","large","large/index","/desktop/icons",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","logos","logos/index","/desktop/icons",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","mini","mini/index","/desktop/icons",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","normal","normal/index","/desktop/icons",$subunset) ?></B></DT></DL></UL>
<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/3_dots.xpm.png>","3_dots.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/3dpaint.xpm.png>","3dpaint.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep2.xpm.png>","AfterStep2.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep3.xpm.png>","AfterStep3.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep4.xpm.png>","AfterStep4.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep5.xpm.png>","AfterStep5.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep6.xpm.png>","AfterStep6.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/AfterStep.xpm.png>","AfterStep.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/arrow-dots.xpm.png>","arrow-dots.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/arrow.xpm.png>","arrow.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockBlue.xpm.png>","ASBBlockBlue.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockClear.xpm.png>","ASBBlockClear.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockConvexBlue.xpm.png>","ASBBlockConvexBlue.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockDefault.xpm.png>","ASBBlockDefault.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockGreen.xpm.png>","ASBBlockGreen.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockMarble.xpm.png>","ASBBlockMarble.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockRed.xpm.png>","ASBBlockRed.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockSlate.xpm.png>","ASBBlockSlate.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockTransparent.xpm.png>","ASBBlockTransparent.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockWater.xpm.png>","ASBBlockWater.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ASBBlockWhite.xpm.png>","ASBBlockWhite.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/aterm.png>","aterm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/author.xpm.png>","author.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/bluebar.xpm.png>","bluebar.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/BookArrows.xpm.png>","BookArrows.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Bookshelf.xpm.png>","Bookshelf.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Brush.xpm.png>","Brush.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/CDrom2.xpm.png>","CDrom2.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/CDrom.xpm.png>","CDrom.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ComputerPC.xpm.png>","ComputerPC.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Computer.xpm.png>","Computer.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Configure.png>","Configure","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/cpuchip.xpm.png>","cpuchip.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/darkbluebar.xpm.png>","darkbluebar.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Database.xpm.png>","Database.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Debug.xpm.png>","Debug.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/DeskGlobe.xpm.png>","DeskGlobe.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/disk.builder.xpm.png>","disk.builder.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/draw.xpm.png>","draw.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/east.xpm.png>","east.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/emacs.png>","emacs","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/eterm.png>","eterm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Eyecon.xpm.png>","Eyecon.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/FileFolders.xpm.png>","FileFolders.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Folder.xpm.png>","Folder.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/GNUSpace.xpm.png>","GNUSpace.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/greenbar.xpm.png>","greenbar.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/hostmanager.xpm.png>","hostmanager.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Info.xpm.png>","Info.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Install.xpm.png>","Install.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/interface.xpm.png>","interface.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/KeyPower.xpm.png>","KeyPower.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/KeysOnChain.xpm.png>","KeysOnChain.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/linux-penguin.xpm.png>","linux-penguin.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-app.xpm.png>","mini-app.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-as.xpm.png>","mini-as.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-exit.xpm.png>","mini-exit.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-folder.xpm.png>","mini-folder.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-menu.xpm.png>","mini-menu.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini-recycler.xpm.png>","mini-recycler.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/monalisa.xpm.png>","monalisa.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Monitor.xpm.png>","Monitor.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/netscape.xpm.png>","netscape.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/NetworkInfoManager.xpm.png>","NetworkInfoManager.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Network.xpm.png>","Network.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/OldFashionedRadio.xpm.png>","OldFashionedRadio.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/os8-title.xpm.png>","os8-title.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ostxs.xpm.png>","ostxs.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ostxu.xpm.png>","ostxu.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/ostx.xpm.png>","ostx.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Paint.xpm.png>","Paint.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Plasma.xpm.png>","Plasma.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Publish.xpm.png>","Publish.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/RayTracedGear.xpm.png>","RayTracedGear.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Recycler.xpm.png>","Recycler.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/redbar.xpm.png>","redbar.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/RedFire.xpm.png>","RedFire.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/rxvt.png>","rxvt","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/shutdown2.xpm.png>","shutdown2.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/shutdown.xpm.png>","shutdown.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/southeast.xpm.png>","southeast.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/southwest.xpm.png>","southwest.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/south.xpm.png>","south.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/spreadsheet2.xpm.png>","spreadsheet2.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/spreadsheet.xpm.png>","spreadsheet.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Start.xpm.png>","Start.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/Text.xpm.png>","Text.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/west.xpm.png>","west.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/wharf.xpm.png>","wharf.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/widget.xpm.png>","widget.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/workshop.xpm.png>","workshop.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/writeletter.xpm.png>","writeletter.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/WWW.xpm.png>","WWW.xpm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/xterm.png>","xterm","/desktop/icons",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/YellowBlueRedGeometry.xpm.png>","YellowBlueRedGeometry.xpm","/desktop/icons",$subunset) ?></IMG>
</UL>
<A NAME="CREDITS"><UL><B>CREDITS</B><br></A><PRE>Borrowed from KDE Aqua theme compiled by gregday@ecsis.net :
        large/KAqua.lst
        large/DVD
        large/FolderBlueAqua
        large/HomeAqua
        large/FolderOpenBlueAqua
        large/FolderOpenRedAqua
        large/FolderYellowAqua
        large/Harddrive2
        large/Document
        large/NetworkedGlobe

Icons created by CmdrTaco ( Rob Malda ) http://cmdrtaco.net/yada/icons/ :
        large/CD
        large/CDR
        large/DocumentScroll
        large/Globe
        large/Harddrive
        large/Home
        large/Speaker
        large/Stopsign
        large/RedLight
        large/Typewriter
        large/Window
        large/Chat

        logos/linux-penguin

        normal\Desktop
        normal\Battery
        normal\Bell
        normal\PackageBlack
        normal\Bomb
        normal\Boombox
        normal\Boot
        normal\Brain
        normal\Brushes
        normal\Bug
        normal\Filecabinet2
        normal\Calculator2
        normal\Cardgames
        normal\Cash
        normal\CD
        normal\CDInHand
        normal\CDR
        normal\CDRInHand
        normal\Chair
        normal\Charts
        normal\Chip
        normal\Clock
        normal\Coffee
        normal\ToolbarInHand
        normal\Corkscrew
        normal\Cpufan
        normal\Chat
        normal\Zip
        normal\Zipdisk
        normal\Package
        normal\Crayon
        normal\Cron
        normal\Cube
        normal\CutAndPaste
        normal\Desktop2
        normal\DNA
        normal\Document
        normal\DrawingPad
        normal\Engine
        normal\Eraser
        normal\Ethernet
        normal\ExpansionCard
        normal\Eyedropper
        normal\Fax
        normal\Feather
        normal\Fish
        normal\Floppy
        normal\Floppy525
        normal\Font
        normal\Camera2
        normal\Gear
        normal\Gear2
        normal\Ghost
        normal\Globe
        normal\Glove
        normal\HammerBrown
        normal\Harddrive
        normal\Headphones
        normal\Helm
        normal\House
        normal\Scanner
        normal\Key
        normal\Camera3
        normal\LaserPrinter
        normal\Letter
        normal\Library
        normal\License
        normal\Lifejacket
        normal\Lightbulb
        normal\LockClosed
        normal\MagnifyingGlass
        normal\Mail
        normal\MailBox2
        normal\MailBox3
        normal\MenuEdit
        normal\Modem
        normal\Mona
        normal\MonitorLCD
        normal\Moon
        normal\Mouse
        normal\Move
        normal\MovieProjector
        normal\MusicalNote
        normal\Newspaper
        normal\Trashcan
        normal\Pallette
        normal\PaperClip
        normal\Glue
        normal\PCCase
        normal\PCMCIA
        normal\PDA
        normal\Pen
        normal\PencilCup
        normal\Piano
        normal\Player
        normal\Pliers
        normal\PowerOutlet
        normal\PowerPlug
        normal\InkJetPrinter
        normal\HandshakeTransparent2
        normal\PushPin
        normal\Puzzle
        normal\Pyramid
        normal\Python
        normal\RemoteControl
        normal\Rolodex
        normal\Rubberstamp
        normal\Run
        normal\Safe
        normal\Scissors
        normal\MoonInMonitor
        normal\SCSIConnector
        normal\Shell
        normal\Shredder
        normal\Speaker
        normal\Stamp
        normal\Stickynote
        normal\Stopsign
        normal\Stratacaster
        normal\Cat
        normal\Sword
        normal\Tapemeasure
        normal\Notebook
        normal\Notebook2
        normal\Thumbsup
        normal\Leatherman
        normal\SwissArmyKnife
        normal\RedLight
        normal\Trashcan2
        normal\TV
        normal\Typewriter
        normal\LockOpen
        normal\USB
        normal\Window
        normal\Wireless
        normal\Wrench2
        normal\WritingHand


John T. Folden http://www.erinet.com/jag/NeXTVIEW/ - The NeXTVIEW :
        large/Interface
        large/Computer
        large/Monitor3
        large/Package
        large/Document2
        large/Bookshelf

vferr10626@aol.com (Vinny FERRARI (Marseille,France)) :
        large/NeXTishTerm
        large/Terminal

Laurent Hivet(tildouf)  laurent.hivet@laposte.net :
        large/Monitor1
        large/Monitor2
        normal/Monitor1
        normal/FTP
        normal/PaintEye
        normal/EyeInMonitor
        normal/GIMP
        normal/MailBox
        normal/Calculator
        normal/CDRom
        normal/CISCORouter
        normal/Keyboard
        normal/Chess
        normal/Handshake
        normal/EyeInMonitor2
        normal/MCInMonitor
        normal/People

Nathan Mahon(vaevictus) afterstep.org@vaevictus.net
Original Artwork stolen from http://www.mozilla.org
       logos/png/Thunderbird
       logos/png/Firefox
</PRE></UL>