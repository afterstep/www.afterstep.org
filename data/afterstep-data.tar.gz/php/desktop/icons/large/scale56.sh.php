&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">scale56.sh</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons/large/scale56.sh</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Details"><UL><B>Details</B><br></A><DL class="dense"><DT class="dense"><B>Full path : </B></DT><DD class="dense"><P class="dense">/usr/local/share/afterstep/desktop/icons/large/scale56.sh</P></DD></DL></UL>
<A NAME="ASCII text: "><UL><B>ASCII text: </B><br></A><PRE>#/bin/sh
if test &quot;x$1&quot; = &quot;x&quot; ; then
  echo &quot;Usage : scale56.sh &lt;source_image&gt; [&lt;destination_image&gt;]&quot;;
else
  if test &quot;x$2&quot; = &quot;x&quot; ; then
    out_fname=&quot;$1_out&quot;;
    echo &quot;Using output filename $out_fname&quot;
  else
    out_fname=$2;
  fi
  ascompose -n -o $out_fname -t png -s &quot;&lt;scale width=56 height=56&gt;&lt;img src=$1/&gt; &lt;/scale&gt;&quot;;
fi
</PRE></UL>