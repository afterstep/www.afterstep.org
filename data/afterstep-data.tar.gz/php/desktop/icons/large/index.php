&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/icons/large</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons/large</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/AfterStep3.png>","AfterStep3","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/AfterStep4.png>","AfterStep4","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Bookshelf.png>","Bookshelf","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/CD.png>","CD","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/CDR.png>","CDR","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Chat.png>","Chat","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Computer.png>","Computer","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Document.png>","Document","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Document2.png>","Document2","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/DocumentScroll.png>","DocumentScroll","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/DVD.png>","DVD","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FileCabinet.png>","FileCabinet","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderAqua.png>","FolderAqua","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderAquaBlue.png>","FolderAquaBlue","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderAquaYellow.png>","FolderAquaYellow","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderOpenAqua.png>","FolderOpenAqua","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderOpenBlueAqua.png>","FolderOpenBlueAqua","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/FolderOpenRedAqua.png>","FolderOpenRedAqua","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Globe.png>","Globe","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Harddrive.png>","Harddrive","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Harddrive2.png>","Harddrive2","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Home.png>","Home","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/HomeAqua.png>","HomeAqua","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Interface.png>","Interface","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Monitor1.png>","Monitor1","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Monitor2.png>","Monitor2","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Monitor3.png>","Monitor3","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/NetworkedGlobe.png>","NetworkedGlobe","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/NeXTishTerm.png>","NeXTishTerm","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Package.png>","Package","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/RedLight.png>","RedLight","/desktop/icons/large",$subunset) ?></IMG>
<P class="dense"><? local_doc_url("graphics.php","scale56.sh","scale56.sh","/desktop/icons/large",$subunset) ?></P><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Speaker.png>","Speaker","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Stopsign.png>","Stopsign","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Terminal.png>","Terminal","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Typewriter.png>","Typewriter","/desktop/icons/large",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/large/Window.png>","Window","/desktop/icons/large",$subunset) ?></IMG>
</UL>