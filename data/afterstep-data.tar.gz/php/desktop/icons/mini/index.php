&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/icons/mini</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons/mini</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/App.png>","App","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/applications.png>","applications","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/AS.png>","AS","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/ColorScheme.png>","ColorScheme","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Desktop.png>","Desktop","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Exit.png>","Exit","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/feel.png>","feel","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Folder.png>","Folder","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/GNOMESearchTool.png>","GNOMESearchTool","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Info.png>","Info","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/KDESearchTool.png>","KDESearchTool","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/KDEWallpapers.png>","KDEWallpapers","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/look.png>","look","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Menu.png>","Menu","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Mona.png>","Mona","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/MoonInMonitor.png>","MoonInMonitor","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Mouse.png>","Mouse","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Puzzle.png>","Puzzle","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Recycler.png>","Recycler","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/RemoteControl.png>","RemoteControl","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Stopsign.png>","Stopsign","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/theme.png>","theme","/desktop/icons/mini",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/mini/Windows.png>","Windows","/desktop/icons/mini",$subunset) ?></IMG>
<P class="dense"><? local_doc_url("graphics.php","scale16.sh","scale16.sh","/desktop/icons/mini",$subunset) ?></P></UL>