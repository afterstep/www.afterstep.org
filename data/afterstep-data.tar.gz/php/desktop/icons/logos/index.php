&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/icons/logos</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons/logos</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/AfterStep.png>","AfterStep","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/AfterStep2.png>","AfterStep2","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/AfterStep4.png>","AfterStep4","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/AfterStep5.png>","AfterStep5","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/aterm.png>","aterm","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/BitchX.png>","BitchX","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/Firefox.png>","Firefox","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/gimp.png>","gimp","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/GNOME.png>","GNOME","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/GNU.png>","GNU","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/GNUStep.png>","GNUStep","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/GNUStep3D.png>","GNUStep3D","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/GNUStepGlow.png>","GNUStepGlow","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/KDE.png>","KDE","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/konqueror.png>","konqueror","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/linux-penguin.png>","linux-penguin","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/mozilla.png>","mozilla","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/MSWindows.png>","MSWindows","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/NEdit.png>","NEdit","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/Opera.png>","Opera","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/PDF.png>","PDF","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/Real.png>","Real","/desktop/icons/logos",$subunset) ?></IMG>
<P class="dense"><? local_doc_url("graphics.php","scale48.sh","scale48.sh","/desktop/icons/logos",$subunset) ?></P><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/Thunderbird.png>","Thunderbird","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/VIM.png>","VIM","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/Xmms.png>","Xmms","/desktop/icons/logos",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/logos/XWindow.png>","XWindow","/desktop/icons/logos",$subunset) ?></IMG>
</UL>