&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/desktop/icons/dots</FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">/usr/local/share/afterstep/desktop/icons/dots</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Files"><UL><B>Files</B><br></A><? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/3_dots.png>","3_dots","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow.png>","arrow","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_dots.png>","arrow_dots","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_gr_medium.png>","arrow_gr_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_gr_small.png>","arrow_gr_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_medium.png>","arrow_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_narrow.png>","arrow_narrow","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_short_medium.png>","arrow_short_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_short_small.png>","arrow_short_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_small.png>","arrow_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/arrow_tiny.png>","arrow_tiny","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/bar_medium.png>","bar_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/circle_medium.png>","circle_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/lined_arrow.png>","lined_arrow","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/maxmin_unity.png>","maxmin_unity","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/menu_medium.png>","menu_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/oval_medium.png>","oval_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/pin.png>","pin","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/qnx-close-red.png>","qnx-close-red","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/qnx-iconify-red.png>","qnx-iconify-red","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/qnx-menu-red.png>","qnx-menu-red","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/qnx-shade-red.png>","qnx-shade-red","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/shade_unity.png>","shade_unity","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/square_medium.png>","square_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/square_small.png>","square_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/triangle_medium.png>","triangle_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/triangle_squared_medium.png>","triangle_squared_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/triangle_squared_small.png>","triangle_squared_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/window_medium.png>","window_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/window_small.png>","window_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/windows_medium.png>","windows_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/windows_small.png>","windows_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/window_thick.png>","window_thick","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/window_unity.png>","window_unity","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_boxy.png>","x_boxy","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_crooked_small.png>","x_crooked_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_large.png>","x_large","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_medium.png>","x_medium","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_small.png>","x_small","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_thin.png>","x_thin","/desktop/icons/dots",$subunset) ?></IMG>
<? local_doc_url("graphics.php","<IMG SRC=data/php/desktop/icons/dots/x_unity.png>","x_unity","/desktop/icons/dots",$subunset) ?></IMG>
</UL>