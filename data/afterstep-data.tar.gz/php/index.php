&nbsp;<? local_doc_url("graphics.php","bars","/desktop/bars/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","cursors","/desktop/cursors/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","fonts","/desktop/fonts/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","icons","/desktop/icons/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","tiles","/desktop/tiles/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","sounds","/desktop/sounds/index",$srcunset,$subunset) ?>
 &nbsp;<? local_doc_url("graphics.php","buttons","/desktop/buttons/index",$srcunset,$subunset) ?>
 <hr>
<br><table width=100%><tr><td width=50%><b><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1"></FONT></b></td><td width=50%><FONT face="Tahoma, Arial, Verdana, Helvetica" size="-1">Installed data files - fonts, images and configuration</FONT></td></tr></table><br><hr>
<hr>

<A NAME="Subdirectories"><UL><B>Subdirectories</B><br></A><DL class="dense"><DT class="dense"><B><? local_doc_url("graphics.php","desktop","desktop/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","backgrounds","backgrounds/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","applications","applications/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","colorschemes","colorschemes/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","feels","feels/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","looks","looks/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","scripts","scripts/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","themes","themes/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","non-configurable","non-configurable/index","",$subunset) ?></B></DT><DT class="dense"><B><? local_doc_url("graphics.php","start","start/index","",$subunset) ?></B></DT></DL></UL>
<A NAME="Files"><UL><B>Files</B><br></A><P class="dense"><? local_doc_url("graphics.php","animate","animate","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","autoexec","autoexec","",$subunset) ?></P><? local_doc_url("graphics.php","<IMG SRC=data/php/banner.png>","banner","",$subunset) ?></IMG>
<P class="dense"><? local_doc_url("graphics.php","base","base","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","database","database","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","pager","pager","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","wharf","wharf","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","winlist","winlist","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","standard_categories","standard_categories","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","kcsrc_template","kcsrc_template","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","gtkrc-2.0_template","gtkrc-2.0_template","",$subunset) ?></P><P class="dense"><? local_doc_url("graphics.php","gtkrc_template","gtkrc_template","",$subunset) ?></P></UL>
<A NAME="CREDITS"><UL><B>CREDITS</B><br></A><PRE>icons creadits: see desktop/icons/CREDITS
fonts credits:  see desktop/fonts/CREDITS

backgrounds credits: 

Laurent Hivet(tildouf)  laurent.hivet@laposte.net :
    backgrounds/.Japanese
    backgrounds/.Cell

Ales Ledvinka: 
    backgrounds/.StormySkies

Jeremy(ShadowGod) shadowgod@hacksess.com :
    backgrounds/.CloudsOfDoubt

Shane Sellers(happyhobo) hokeypokey31@earthlink.net:
    backgrounds/.OceanWave

</PRE></UL>